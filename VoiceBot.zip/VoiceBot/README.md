# Voice Bot (Android)

Background voice assistant: wake word -> command -> call / WhatsApp.

## Build (laptop par)
1. Android Studio install karein (https://developer.android.com/studio).
2. File > Open > is `VoiceBot` folder ko select karein. Gradle sync hone dein.
3. Phone par Developer options + USB debugging on karein, phone USB se jorein.
4. Run (▶) dabayein, ya Build > Build APK(s) se APK bana kar phone mein install karein.

## Phone par pehli baar
- App kholein, wake word set karein (default: jarvis), Start dabayein.
- Mic, Contacts, Phone, Notifications ki ijazat dein.
- "Display over other apps" on karein (isi se bot background se Phone/WhatsApp khol sakta hai).
- "Battery settings" mein Voice Bot ko "Unrestricted" karein. Infinix (XOS) mein
  Settings > Apps > Voice Bot > Autostart bhi on karein, warna system app band kar deta hai.

## Commands
- "jarvis, Sami ko call karo"
- "jarvis, WhatsApp kholo"
- "jarvis, Sadia ko message likho hello kaise ho"  (chat khulti hai, text likha hua; Send aap dabate hain)
- Sirf "jarvis" bolein to bot "Ji?" kehta hai, phir command bolein.

## Hadood
- Contacts ka naam phone ke contacts jaisa hi bolna hoga (Urdu mode mein contact Urdu mein save hona chahiye).
- Wake word Google ki SpeechRecognizer se suna jata hai (internet chahiye), isliye har dafa chhota beep aa sakta hai.
- WhatsApp message khud "Send" nahi hota; iske liye AccessibilityService alag se banani paregi.

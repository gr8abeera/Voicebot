package com.example.voicebot

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("vb", Context.MODE_PRIVATE)

    var wake: String
        get() = sp.getString("wake", "jarvis") ?: "jarvis"
        set(v) = sp.edit().putString("wake", v).apply()

    // "en-IN" (English/Hinglish names) or "ur-PK" (Urdu)
    var lang: String
        get() = sp.getString("lang", "en-IN") ?: "en-IN"
        set(v) = sp.edit().putString("lang", v).apply()

    // country code for numbers saved starting with 0 (92 = Pakistan)
    var cc: String
        get() = sp.getString("cc", "92") ?: "92"
        set(v) = sp.edit().putString("cc", v).apply()
}

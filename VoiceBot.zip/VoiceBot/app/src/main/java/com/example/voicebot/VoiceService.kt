package com.example.voicebot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.ServiceCompat
import java.util.Locale

class VoiceService : Service(), RecognitionListener {

    private var recognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var awaiting = false      // wake word heard, waiting for the command
    private var running = true
    private lateinit var prefs: Prefs

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        val ch = NotificationChannel("vb", "Voice Bot", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        val n = Notification.Builder(this, "vb")
            .setContentTitle("Voice Bot sun raha hai")
            .setContentText("Wake word: ${prefs.wake}")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("en", "IN") }
        startListening()
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    // ---------- listening loop ----------
    private fun startListening() {
        if (!running) return
        handler.post {
            try {
                recognizer?.destroy()
                recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs.lang)
                i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                recognizer?.startListening(i)
            } catch (e: Exception) {
                handler.postDelayed({ startListening() }, 2000)
            }
        }
    }

    override fun onResults(results: Bundle?) {
        val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        if (list.isNotEmpty()) handleHeard(list)
        startListening()
    }

    override fun onError(error: Int) {
        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopSelf(); return }
        if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) awaiting = false
        val delay = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 400L
        handler.postDelayed({ startListening() }, delay)
    }

    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(v: Float) {}
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(p: Bundle?) {}
    override fun onEvent(t: Int, p: Bundle?) {}

    // ---------- wake word + command ----------
    private fun handleHeard(list: List<String>) {
        if (awaiting) { awaiting = false; execute(list[0]); return }
        val wake = prefs.wake.lowercase().trim()
        for (t in list) {
            val idx = t.lowercase().indexOf(wake)
            if (idx >= 0) {
                val rest = t.substring(idx + wake.length).trim()
                if (rest.isBlank()) { awaiting = true; speak("Ji?") } else execute(rest)
                return
            }
        }
    }

    private fun execute(text: String) {
        when (val cmd = Parser.parse(text)) {
            is Cmd.Call -> {
                val c = Contacts.find(this, cmd.spoken)
                if (c == null) { speak("Contact nahi mila"); return }
                speak("${c.first} ko call kar raha hoon")
                val granted = checkSelfPermission(android.Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
                val uri = Uri.fromParts("tel", "+" + Contacts.digits(c.number, prefs.cc), null)
                launch(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri))
            }
            is Cmd.Chat -> {
                val c = Contacts.find(this, cmd.spoken)
                if (c == null) {
                    if (cmd.body == null) {
                        val i = packageManager.getLaunchIntentForPackage("com.whatsapp")
                        if (i != null) { speak("WhatsApp khol raha hoon"); launch(i) } else speak("WhatsApp nahi mila")
                    } else speak("Contact nahi mila")
                    return
                }
                val body = cmd.body?.let { Parser.cleanBody(it, c) }.orEmpty()
                val url = "https://wa.me/" + Contacts.digits(c.number, prefs.cc) +
                        (if (body.isNotBlank()) "?text=" + Uri.encode(body) else "")
                speak(if (body.isNotBlank()) "${c.first} ke liye message likh diya" else "${c.first} ki chat khol raha hoon")
                val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.whatsapp")
                if (i.resolveActivity(packageManager) == null) i.setPackage(null)
                launch(i)
            }
            Cmd.Unknown -> speak("Samajh nahi aaya")
        }
    }

    private fun launch(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(i) } catch (e: Exception) { speak("Khul nahi saka") }
    }

    private fun speak(msg: String) {
        tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "vb")
    }
}

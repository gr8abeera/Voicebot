package com.example.voicebot

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var wake: EditText
    private lateinit var cc: EditText
    private lateinit var langGroup: RadioGroup
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 14f; setPadding(0, 32, 0, 0) }

        root.addView(TextView(this).apply { text = "🎙️ Voice Bot"; textSize = 26f })

        root.addView(label("Wake word (jis se bot jaagta hai)"))
        wake = EditText(this).apply { setText(prefs.wake); setSingleLine() }
        root.addView(wake)

        root.addView(label("Bolne ki zubaan"))
        langGroup = RadioGroup(this)
        val en = RadioButton(this).apply { text = "English / Hinglish (en-IN)"; id = 1 }
        val ur = RadioButton(this).apply { text = "اردو (ur-PK)"; id = 2 }
        langGroup.addView(en); langGroup.addView(ur)
        langGroup.check(if (prefs.lang == "ur-PK") 2 else 1)
        root.addView(langGroup)

        root.addView(label("Country code (0 se shuru numbers ke liye)"))
        cc = EditText(this).apply { setText(prefs.cc); inputType = InputType.TYPE_CLASS_NUMBER }
        root.addView(cc)

        root.addView(Button(this).apply { text = "Start"; setOnClickListener { startBot() } })
        root.addView(Button(this).apply {
            text = "Stop"
            setOnClickListener {
                stopService(Intent(this@MainActivity, VoiceService::class.java))
                status.text = "Band hai"
            }
        })
        root.addView(Button(this).apply {
            text = "Battery settings (zaroori)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATIONS_SETTINGS)) }
        })
        status = TextView(this).apply { text = "Band hai"; setPadding(0, 32, 0, 0) }
        root.addView(status)
        root.addView(TextView(this).apply {
            textSize = 13f
            text = "Istemal: \"${prefs.wake}, Sami ko call karo\" ya \"${prefs.wake}, Sadia ko message likho hello\""
        })
        setContentView(root)
    }

    private fun startBot() {
        prefs.wake = wake.text.toString().trim().ifBlank { "jarvis" }
        prefs.cc = cc.text.toString().trim().ifBlank { "92" }
        prefs.lang = if (langGroup.checkedRadioButtonId == 2) "ur-PK" else "en-IN"

        val need = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        )
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) { requestPermissions(missing.toTypedArray(), 1); return }
        proceed()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        proceed()
    }

    private fun proceed() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Mic ki ijazat zaroori hai", Toast.LENGTH_LONG).show(); return
        }
        // Needed so the bot can open Phone/WhatsApp while running in the background
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "\"Display over other apps\" on karein, phir dobara Start dabayein", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startForegroundService(Intent(this, VoiceService::class.java))
        status.text = "Chal raha hai — wake word: ${prefs.wake}"
    }
}

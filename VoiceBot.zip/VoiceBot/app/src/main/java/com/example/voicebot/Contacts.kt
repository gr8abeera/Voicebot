package com.example.voicebot

import android.content.Context
import android.provider.ContactsContract.CommonDataKinds.Phone

data class Contact(val name: String, val number: String) {
    val first: String get() = name.trim().split(" ").first()
}

object Contacts {
    /** Finds the contact whose name (or first name) appears in the spoken text. */
    fun find(ctx: Context, spoken: String): Contact? {
        val s = spoken.lowercase()
        var best: Contact? = null
        var bestLen = 0
        try {
            ctx.contentResolver.query(
                Phone.CONTENT_URI,
                arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0) ?: continue
                    val num = c.getString(1) ?: continue
                    val full = n.lowercase().trim()
                    val first = full.split(" ").first()
                    val len = when {
                        full.isNotEmpty() && s.contains(full) -> full.length
                        first.length >= 3 && s.contains(first) -> first.length
                        else -> 0
                    }
                    if (len > bestLen) { best = Contact(n, num); bestLen = len }
                }
            }
        } catch (e: SecurityException) { }
        return best
    }

    /** Digits only, with country code, e.g. 03001234567 -> 923001234567 */
    fun digits(num: String, cc: String): String {
        val d = num.filter { it.isDigit() }
        return when {
            num.trim().startsWith("+") -> d
            d.startsWith("00") -> d.drop(2)
            d.startsWith("0") -> cc + d.drop(1)
            else -> d
        }
    }
}

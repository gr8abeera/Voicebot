package com.example.voicebot

sealed class Cmd {
    data class Call(val spoken: String) : Cmd()
    data class Chat(val spoken: String, val body: String?) : Cmd()
    object Unknown : Cmd()
}

object Parser {
    private val callRe = Regex("\\b(call|phone|dial)\\b|کال|فون|ڈائل|कॉल|फोन", RegexOption.IGNORE_CASE)
    private val waRe = Regex("whats\\s?app|whatsap|واٹس|وٹس|व्हाट्सएप|वाट्सएप", RegexOption.IGNORE_CASE)
    private val strong = Regex("(likho|likh|likhna|type|لکھو|لکھ|کہو|लिखो)", RegexOption.IGNORE_CASE)
    private val weak = Regex("(message|msg|bhejo|میسج|پیغام|بھیجو|मैसेज)", RegexOption.IGNORE_CASE)

    private val filler = setOf(
        "ko", "کو", "को", "karo", "kardo", "kar", "do", "کرو", "کریں", "کہ", "ke", "ki",
        "pe", "par", "whatsapp", "message", "msg", "type", "likho", "to", "say", "that"
    )

    fun parse(text: String): Cmd {
        val call = callRe.find(text)
        val msg = strong.find(text) ?: weak.find(text)
        val wa = waRe.containsMatchIn(text)

        if (call != null && (msg == null || call.range.first < msg.range.first)) return Cmd.Call(text)
        if (msg != null) return Cmd.Chat(text, text.substring(msg.range.last + 1))
        if (wa) return Cmd.Chat(text, null)
        return Cmd.Unknown
    }

    /** Removes the contact name and filler words from the start of the message body. */
    fun cleanBody(body: String, c: Contact): String {
        var words = body.replace(c.name, "", true).replace(c.first, "", true)
            .split(Regex("\\s+")).filter { it.isNotBlank() }
        while (words.isNotEmpty() && words.first().lowercase().trim(',', ':', '.') in filler) {
            words = words.drop(1)
        }
        return words.joinToString(" ")
    }
}
